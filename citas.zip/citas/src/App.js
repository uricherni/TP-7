import React from 'react';
import Formularios from './components/Formulario';
import Lista from './components/lista';
import nav from './components/nav';
import './components/estilos.css';
function App() {
  
  return (
  // <Lista></Lista>
   <Formularios></Formularios>
     
  );
}

export default App;

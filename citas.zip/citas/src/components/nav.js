import React from 'react';



const nav = () => (

<h1>ADMINISTRADOR DE PACIENTES</h1>
    
)
export default nav;
